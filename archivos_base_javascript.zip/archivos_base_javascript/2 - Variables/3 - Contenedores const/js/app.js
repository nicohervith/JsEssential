"use strict"

const pi = 3.1416;

// pi = 15; 
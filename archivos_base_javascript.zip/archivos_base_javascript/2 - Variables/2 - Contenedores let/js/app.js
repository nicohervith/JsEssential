"use strict"

var nombre = 'Sergio';

console.log(nombre)

function saludo() {
  let nombre = 'yacafx';
    console.log(nombre)
    
 let edad = 34; 
  console.log(edad)
}

 console.log(edad)

saludo();
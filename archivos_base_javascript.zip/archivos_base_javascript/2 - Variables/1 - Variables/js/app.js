"use strict"

var nombre = "Sergio";
"use strict"

//********************************
//*** Iterando arreglos con for...in

var platillos = ["ceviche", "tacos", "pasta"];

for ( let i in platillos) {
    console.log(platillos[i])
}
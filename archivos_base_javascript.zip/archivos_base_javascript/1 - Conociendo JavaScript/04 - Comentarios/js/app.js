// alert('Hola desde un archivo externo');

// Este es un mensaje de la consola
console.log('Hola consola');
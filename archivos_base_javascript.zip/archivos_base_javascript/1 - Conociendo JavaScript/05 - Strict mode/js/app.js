"use strict"


// alert('Hola desde un archivo externo');

// Este es un mensaje de la consola
console.log('Hola consola');

var x; 

x = "3.1416";

var publicData = "Hola";
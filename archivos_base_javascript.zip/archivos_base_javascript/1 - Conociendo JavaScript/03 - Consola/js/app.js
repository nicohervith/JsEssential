alert('Hola desde un archivo externo');

console.log('Hola consola');

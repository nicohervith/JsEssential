"use strict"

//********************************
//*** Carga de documento

window.addEventListener('load', function() {
  console.log('El contenido de la ventana se ha cargado');

  
});

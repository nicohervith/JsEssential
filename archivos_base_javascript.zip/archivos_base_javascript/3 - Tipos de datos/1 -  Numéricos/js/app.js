"use strict"

var edad = 35;

var cantidad = "100";

var nuevaCantidad = Number(cantidad);

parseInt()

parseFloat()
"use strict"

var simbolo1 = Symbol();
var simbolo2 = Symbol();

var ambiente = Symbol('dev');
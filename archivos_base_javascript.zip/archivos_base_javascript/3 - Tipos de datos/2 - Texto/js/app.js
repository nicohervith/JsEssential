"use strict"

var bebida = "agua";

var comida = 'ceviche';

var instrucción = "El platillo se llama 'ceviche' ";

var edad = 34;

var edadtxt = String(edad)
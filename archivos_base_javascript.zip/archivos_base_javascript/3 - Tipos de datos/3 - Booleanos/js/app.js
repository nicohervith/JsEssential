"use strict"

var activo = false;

var estado = Boolean( 10 > 9)
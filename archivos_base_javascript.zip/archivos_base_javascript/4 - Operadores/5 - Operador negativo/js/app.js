"use strict"

//********************************
//*** Operador negativo

var datoA = 10;
var datoB = -datoA;

console.log("El valor de datoA es "+ datoA +", después del operador negativo datoB: "+ datoB);
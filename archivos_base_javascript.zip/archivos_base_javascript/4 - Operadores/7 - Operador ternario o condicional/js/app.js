"use strict"

//********************************
//*** Operador ternario o condicional

var datoA = 110;
var datoB = 20;


// Condición ? TRUE : FALSE
var resultado = datoA > datoB ? "Si es mayor" : "No es mayor";

console.log("El resultado con el operador ternario u operador condicional es: ", resultado);


"use strict"

//********************************
//*** Creando tu primer arreglo

var platillos = [ "ceviche", "tacos", "pasta"];

var bebidas = new Array( "Jamaica", "Chicha Morada", "Pozol" );

console.log(Array.isArray(platillos), bebidas)
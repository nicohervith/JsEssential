"use strict"

//********************************
//*** Operaciones básicas de un arreglo

var platillos = ["ceviche", "tacos", "pasta"];

console.log('Antes:', platillos);

//platillos.push("Tostadas");

//platillos.push("Queso");

// platillos.pop();
// platillos.pop();

var mensaje = platillos.join();
console.log( mensaje);

//console.log('Después:', platillos);
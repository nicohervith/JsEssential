"use strict"

//********************************
//*** Arreglos multidimensionales | Arreglo de arreglos

var platillos = ["ceviche", "tacos", "pasta"];
var paises = ["Perú", "México", "Italia"];


var menu = [ platillos, paises ];

console.log( menu[1][0]  )

"use strict"

//********************************
//*** Medir y acceder a un arreglo

var platillos = ["ceviche", "tacos", "pasta", "tostadas"];


console.log("Hay "+ platillos.length + " platillos en el menú");

var platillo = platillos[platillos.length -1];

console.log("El platillo seleccionado es: ", platillo)
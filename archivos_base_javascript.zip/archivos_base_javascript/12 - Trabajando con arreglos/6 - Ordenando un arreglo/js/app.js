"use strict"

//********************************
//*** Ordenando un arreglo

var platillos = ["Ceviche", "Tacos", "Pasta"];

console.log('Antes: ', platillos);

platillos.sort(); 

console.log('Ordenado: ', platillos);

platillos.reverse(); 

console.log('Después: ', platillos);


platillos.reverse(); 

console.log('Reversa de nuevo: ', platillos);
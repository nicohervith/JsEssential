"use strict"

//********************************
//*** Inicialización de parámetros

function contar(cantidad = 20) {
	console.log('Total: ', cantidad);
}

contar(100);
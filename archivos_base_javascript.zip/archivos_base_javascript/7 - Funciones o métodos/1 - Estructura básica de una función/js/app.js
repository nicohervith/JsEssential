"use strict"

//********************************
//*** Estructura básica de una función

function saludar() {
    var saludo = "Hola Mundo";
    //console.log(saludo);
    return saludo;
}

saludar();
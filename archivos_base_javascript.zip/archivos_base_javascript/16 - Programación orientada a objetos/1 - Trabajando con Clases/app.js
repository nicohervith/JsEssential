"use strict";

//********************************
//*** Trabajando con Clases

class Pantalla {
    constructor() {

    }
}


const tvSala = new Pantalla();
const tvHabitacion = new Pantalla();

// function Pantalla(marca, modelo, pulgadas) {
//     this.marca = marca;
//     this.modelo = modelo;
//     this.pulgadas = pulgadas;
// }


// Pantalla.prototype.encendido = function () {
//     console.log(`La pantalla ${this.marca} se ha encendido`);
// };


// Pantalla.prototype.volumen = function () {
//     console.log(`El volumen se ha modificado`);
// };

// Pantalla.prototype.info = function () {
//     console.log(`La pantalla ${this.marca} de modelo ${this.modelo} es de ${this.pulgadas} pulgadas`);
// }

// const tvSala = new Pantalla('Master', 'Oasis', 55);
// const tvHabitacion = new Pantalla('Origin', 'Artemis', 80);
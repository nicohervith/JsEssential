"use strict"

//********************************0
//*** Ciclo DO..WHILE | Ciclo Indefinido
// Iteración indeterminada o desconocida


var productos = 5; 


do { 
   	console.log( 'Producto vendido');
   	productos--;
   debugger;
} 
while(productos>=1)
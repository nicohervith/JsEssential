"use strict"

//********************************
//*** Métodos de transformación

var mensaje = "Estoy aprendiendo JavaScript";
var mensaje2 = " y programación";
var total = 123456;

var resultado;

//resultado = total.toString();
// resultado = mensaje.toLowerCase();
// resultado = mensaje.toUpperCase();


resultado = mensaje.concat(mensaje2, ' y tengo muchas ideas', ' 123', ' 123', ' 123', ' 123', ' 123', ' 123', ' 123');


console.log(resultado);
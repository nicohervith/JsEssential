"use strict"

//********************************
//*** Creando cadena de texto

var pais = 'México';

var comida = new String("Ceviche");


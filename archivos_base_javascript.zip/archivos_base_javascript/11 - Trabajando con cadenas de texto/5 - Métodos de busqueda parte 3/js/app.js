"use strict"

//********************************
//*** Métodos búsqueda | Parte 3

var mensaje = "Estoy aprendiendo JavaScript";
var resultado;


// startsWith
// resultado = mensaje.startsWith("es");

// var textoEn =  mensaje.indexOf("JavaScript")
// resultado = mensaje.startsWith("Ja", textoEn);



// endsWith
// resultado = mensaje.endsWith("JavaScript");



// includes
resultado = mensaje.includes("Estoy", 6);



console.log(resultado);
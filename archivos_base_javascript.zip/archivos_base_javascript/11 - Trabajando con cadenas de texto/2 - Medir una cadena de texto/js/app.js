"use strict"

//********************************
//*** Medir una cadena de texto

var mensaje = "Estoy aprendiendo JavaScript";

console.log("La cadena de texto tiene: " + mensaje.length + " letras");
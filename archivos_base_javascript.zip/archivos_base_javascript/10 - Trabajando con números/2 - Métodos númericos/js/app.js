"use strict"

//********************************
//*** Métodos númericos


var numero = "10";


console.log('Number: ', typeof numero, typeof Number(numero));
console.log('parseInt: ',  parseInt(numero));
console.log('parseFloat: ', Number.parseFloat(numero));
console.log('isNaN: ', isNaN(numero));
console.log('isInteger: ', Number.isInteger(numero));
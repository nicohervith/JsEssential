"use strict"

//********************************
//*** Propiedades númericas de instancias

var numero = 2.5;

console.log("toExponential: ", numero.toExponential(4));

console.log("toFixed: ", numero.toFixed(2));

console.log("toPrecision: ", numero.toPrecision(6));

console.log("toString: ", typeof numero.toString());
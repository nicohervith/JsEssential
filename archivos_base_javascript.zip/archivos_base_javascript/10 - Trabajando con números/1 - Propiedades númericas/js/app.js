"use strict"

//********************************
//*** Propiedades númericas

console.log("MAX_VALUE: ", Number.MAX_VALUE);

console.log("MIN_VALUE: ", Number.MIN_VALUE);

console.log("NEGATIVE_INFINITY: ", Number.NEGATIVE_INFINITY);

console.log("NEGATIVE_INFINITY: ", Number.POSITIVE_INFINITY);

console.log("NaN: ", Number.NaN);
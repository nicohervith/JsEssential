var expresion1 = /\bcat\b/;

console.log(expresion1.test("cat"));
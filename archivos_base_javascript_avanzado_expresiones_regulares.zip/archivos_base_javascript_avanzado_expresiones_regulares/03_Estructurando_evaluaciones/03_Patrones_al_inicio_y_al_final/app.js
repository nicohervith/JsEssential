var expresionInicio = /^Any/;
var expresionFin = /JavaScript$/
var expIniciFin = /^Any|JavaScript$/

// ^ Inicio
// $ Fin


console.log(expIniciFin.test('Any app that can be imagined can be made in JavaScript'));
var expresion1 = /pollo|res|pescado/;
console.log(expresion1);

console.log(expresion1.test('El cliente pidió tacos'));
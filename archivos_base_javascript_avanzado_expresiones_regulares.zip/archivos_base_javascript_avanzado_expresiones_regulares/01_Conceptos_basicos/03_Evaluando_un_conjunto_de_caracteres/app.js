//var expresion1 = /[0123456789]/;
var expresion1 = /[0-9a-zA-Z]/;

console.log(expresion1.test('Sucedió en 1996'));
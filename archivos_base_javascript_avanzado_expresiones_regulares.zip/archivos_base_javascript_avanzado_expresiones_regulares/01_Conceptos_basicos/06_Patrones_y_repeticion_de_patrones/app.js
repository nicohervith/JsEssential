//var expresion1 = /\d+/;
var expresion1 = /\d*/;

//console.log(expresion1.test('1997'));
console.log(expresion1.test('2008'));


//  +   *
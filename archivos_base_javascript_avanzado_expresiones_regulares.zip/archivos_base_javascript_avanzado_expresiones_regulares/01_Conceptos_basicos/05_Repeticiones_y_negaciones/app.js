//var expresion1 = /[\d]/;

//console.log(expresion1.test('29-junio-2007'));

var expresion2 = /[^01]/;

console.log(expresion2.test('10101002100110001'));
var expresion1 = new RegExp('abc');

var expresion2 = /abc/;

var parrafo = /text1 \/n texto2 /;
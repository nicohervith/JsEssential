var expresion1 = new RegExp('abc');
console.log(expresion1.test('abcdef'));

var expresion2 = /Hola Mundo/;

console.log(expresion2.test('El primer programa es Hola Mundo'));
var expresion1 = /Hola mun?do/;

console.log(expresion1.test('Hola mudo'));
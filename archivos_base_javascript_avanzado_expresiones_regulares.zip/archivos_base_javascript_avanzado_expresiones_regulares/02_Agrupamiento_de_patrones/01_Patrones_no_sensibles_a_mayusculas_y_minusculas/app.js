var expresion1 = /Hola Mundo/i;


console.log(expresion1.test('Hola mundo'));
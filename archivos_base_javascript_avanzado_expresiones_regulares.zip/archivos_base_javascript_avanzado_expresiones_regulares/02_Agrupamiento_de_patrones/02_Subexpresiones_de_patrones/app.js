var expresion1 = /Woo+(hoo+)+/i;

//Woohooooooo!

console.log(expresion1.test('Wooohooohooohooohoooooooohooohooohooohooohooo'));
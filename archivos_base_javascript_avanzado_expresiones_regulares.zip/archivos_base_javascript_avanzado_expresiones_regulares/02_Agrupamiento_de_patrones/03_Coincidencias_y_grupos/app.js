var expresion1 = /\d+/.exec('Del año 1984')

console.log(expresion1);

console.log("Hasta 1994".match(/\d+/))
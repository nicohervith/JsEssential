var mensaje = 'Estahistoriacontinuara';

//  \W  Cualquier carácter que no sea alfanumérico
//  \S Cualquier carácter que no sea un espacio en blanco

console.log(mensaje.search(/\W/));
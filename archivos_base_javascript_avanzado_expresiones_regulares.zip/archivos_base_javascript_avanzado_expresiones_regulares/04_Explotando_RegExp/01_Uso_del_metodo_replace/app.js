var mensaje = 'El cliente pidió sushi y comió su sushi, sushi, sushi, sushi';

console.log(mensaje.replace(/i/g, 'o'));
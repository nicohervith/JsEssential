function mostrarSaludo (){

    let valor1  ="Hola";
    let valor2 = " mundo";

    console.log( valor1 + valor2);
}

mostrarSaludo();
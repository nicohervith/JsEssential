var util = require('util');


var prueba = "10";

console.log ( util.isString(prueba) )
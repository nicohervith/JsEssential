let lista = [ "uno", "dos", "tres"];

let curso = {
    tema:"NodeJS",
    leccion:"datos compuestos"
};

console.log( curso.tema)
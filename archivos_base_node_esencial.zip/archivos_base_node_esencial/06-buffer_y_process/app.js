 

process.env.colorFavorito = "rojo"
console.log( process.env.colorFavorito);
var moment = require('moment');

console.log(  moment('1999-12-31').format('DD/MM/YY').toString() );
var miModulo = {

    multiplicar: function(valor1){
        console.log( valor1 * 3);
    },
    dividir: function(valor1){
        console.log( valor1 / 3);
    }
}

module.exports = miModulo; 
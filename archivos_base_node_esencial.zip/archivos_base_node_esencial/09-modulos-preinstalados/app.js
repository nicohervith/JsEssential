var miModulo = require('./miModulo');

miModulo.multiplicar(10);
miModulo.dividir(60)
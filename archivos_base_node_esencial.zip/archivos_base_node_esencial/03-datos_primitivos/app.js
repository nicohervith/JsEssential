var nombre = "Teodoro";

    nombre = true;

    console.log(nombre)